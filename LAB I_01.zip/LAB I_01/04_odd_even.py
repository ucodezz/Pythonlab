a = int(input('enter first number\n'))
b = int(input('enter second number\n'))
c = int(input('enter third number\n'))

if(a%2 == 0):
    print(f'{a} is even')
else:
    print(f'{a} is odd')


# GREATER THAN

# if(a>b and a>c):
#     print(f'{a} is greatest')
# elif(b>c):
#     print(f'{b} is gratest')
# else:
#     print(f'{c} is greatest')




