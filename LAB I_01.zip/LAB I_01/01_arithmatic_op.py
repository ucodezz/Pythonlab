a = int(input('enter a\n'))
b = int(input('enter b\n'))

# Arithmetic
print('the sum of x and y is : ', a+b);
print('the subtraction of x and y is : ', a-b);
print('the multiplication of x and y is : ', a*b);
print('the float division of x and y is : ', a/b);
print('the int division of x and y is : ', a//b);
print('the modulous of x and y is : ', a%b);