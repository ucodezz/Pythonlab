a = int(input('enter a\n'))
b = int(input('enter b\n'))


# Relational
print('a is smaller than b', a<b);
print('a is greater than b', a>b);
print('a is equal to b ', a==b);
print('a is not qual to b ', a!=b);
print('a is smaller than equal to', a<=b);
print('a is greater than equal to', a>=b);

# Logical
print('AND', a and b);
print('OR', a or b);
print('NOT', not a);