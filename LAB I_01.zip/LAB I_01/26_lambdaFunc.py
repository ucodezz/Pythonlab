l1 = [1,2,3,4,5]

s=map(lambda i: i*i, l1)
print(list(s))
    



