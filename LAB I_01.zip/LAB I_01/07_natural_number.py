num = int(input('enter a number\n'))

sum = 0
for i in range(1, num+1):
    sum += i
print('the sum of ', num, ' number is : ', sum)

