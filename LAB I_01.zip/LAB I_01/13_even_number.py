num = int(input('enter a number'))
i = 0
while(i < num*2):
    print(i)
    i = i + 2
    