# import functools

# METHOD 1
# l1 = [1,2,3,4,5]
# a = functools.reduce(lambda a, b: a+b, l1)
# print(a)

# METOD 2
l1 = [1,2,3,4,5]
sum = print(sum([x for x in l1]))

# METHOD 3
# for i in l1:
#     sum += i
# print(sum)